/************************************************************************************************************************************/
/** @file		x
 * 	@brief		x
 * 	@details	x
 *
 *  @target     MSP430F5438A/CC2541/MSP430F5529
 *  @board      TrxEB/CC2541EMK/5529-Launchpad
 *
 *  @author     Justin Reina, Firmware Engineer, Misc. Company
 *  @created    6/19/17
 *  @last rev   6/19/17
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Misc. Product related source files are the explicit property of
 * 			Misc. Company. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/


/************************************************************************************************************************************/
/**	@fcn		int main(void)
 *  @brief		x
 *  @details	x
 *
 *  @section	Purpose
 *  	x
 *
 *  @param		[in]	name	descrip
 *
 *  @param		[out]	name	descrip
 *
 *  @return		(type) descrip
 *
 *  @pre		x
 *
 *  @post		x
 *
 *  @section	Operation
 *		x
 *		
 *  @section	Opens
 *  	x
 *
 *  @section	Hazards & Risks
 *  	x
 *
 *	@section	Todo
 *		x
 *
 *  @section	Timing
 *  	x
 *
 *  @note		x
 */
/************************************************************************************************************************************/


//------------------------------------------------------------A Delimiting Note-----------------------------------------------------//

/************************************************************************************************************************************/
//																SECTION HEADER														 *
//***********************************************************************************************************************************/

																			/*	note to the side									*/

// a note on top
// that spans multiple lines

// PROTOTYPES, DECLARATIONS AND PREPROC---------------------------------------------------------------------------------------------//

//[1/x]-------------------------------------------STEP 1----------------------------------------------------------------------------//


