#ifndef _GLOBALS_H
#define _GLOBALS_H

//Windows
#include <stdbool.h>
#include <iostream>

//Project
#include "Class.h"

//Constants
const bool verbose = true;

//Locals
void sys_init(void);

#endif /* _GLOBALS_H */

