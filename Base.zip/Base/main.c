/*
 * main.c
 *
 *  Created on: Feb 24, 2018
 *      Author: Justin
 */

int i = 0;

int main(void) {
	i++;
	return 0;
}
